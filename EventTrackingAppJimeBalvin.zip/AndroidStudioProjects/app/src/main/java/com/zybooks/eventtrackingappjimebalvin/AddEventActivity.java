package com.zybooks.eventtrackingappjimebalvin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddEventActivity extends AppCompatActivity {

    private EditText editTextEventTitle;
    private EditText editTextEventDate;
    private Button buttonSaveEvent;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        dbManager = new DatabaseManager(this);

        editTextEventTitle = findViewById(R.id.editTextEventTitle);
        editTextEventDate = findViewById(R.id.editTextEventDate);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);

        buttonSaveEvent.setOnClickListener(v -> {
            String title = editTextEventTitle.getText().toString().trim();
            String date = editTextEventDate.getText().toString().trim();

            if (title.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbManager.addEvent(title, date);

            if (success) {
                Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();
                finish(); // close activity and return to DashboardActivity
            } else {
                Toast.makeText(this, "Failed to save event. Try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
