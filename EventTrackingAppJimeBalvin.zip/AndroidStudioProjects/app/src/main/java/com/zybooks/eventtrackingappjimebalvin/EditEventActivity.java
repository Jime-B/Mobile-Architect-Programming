package com.zybooks.eventtrackingappjimebalvin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class EditEventActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextDate;
    private Button buttonUpdate;
    private DatabaseManager dbManager;
    private int eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        editTextTitle = findViewById(R.id.editTextEventTitle);
        editTextDate = findViewById(R.id.editTextEventDate);
        buttonUpdate = findViewById(R.id.buttonSaveEvent);

        dbManager = new DatabaseManager(this);

        // Get data passed from adapter
        Intent intent = getIntent();
        eventId = intent.getIntExtra("id", -1);
        String title = intent.getStringExtra("title");
        String date = intent.getStringExtra("date");

        editTextTitle.setText(title);
        editTextDate.setText(date);

        buttonUpdate.setOnClickListener(v -> {
            String newTitle = editTextTitle.getText().toString().trim();
            String newDate = editTextDate.getText().toString().trim();

            if (newTitle.isEmpty() || newDate.isEmpty()) {
                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = dbManager.updateEvent(eventId, newTitle, newDate);
            if (updated) {
                Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
                finish(); // Go back to dashboard
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}