package com.zybooks.eventtrackingappjimebalvin;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Button;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    private RecyclerView recyclerViewEvents;
    private Button buttonAddEvent;
    private EventAdapter eventAdapter;
    private DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard);

        dbManager = new DatabaseManager(this);

        recyclerViewEvents = findViewById(R.id.recyclerViewEvents);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);

        recyclerViewEvents.setLayoutManager(new GridLayoutManager(this, 2));

        eventAdapter = new EventAdapter(this);
        recyclerViewEvents.setAdapter(eventAdapter);

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, AddEventActivity.class);
            startActivity(intent);
        });

        loadEvents();
    }

    private void loadEvents() {
        List<Event> events = dbManager.getEvents();
        eventAdapter.setEvents(events);
        eventAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }
}
